# BasketBoss 1.0 (29) — Restore diagnostics handoff

Build 28's monthly Apple Sandbox purchase, Premium activation, Premium retained after reopening, and unlocked Premium recipes were confirmed by the user. Restore Purchases still fails inside Apple's native account-sync operation after Apple Account verification.

Build 29 adds a safe support code for that failure and treats documented cancellation normally. It also preserves useful failure messages across refreshes. It does not claim that the underlying Apple account-sync failure has been resolved.

## Use this build after native verification

Verified release tag: `appstore-build29-restore-diagnostics`

Release commit: `6669a98cfc3eb27540b4e3f111c7b0ff6155c2ee`. Its file tree matches the validated candidate.

Hosted verification passed: 2,693 tests, zero failures or skips, and two existing TODOs; 12 StoreKit tests; Cook navigation; four strict keyboard cases; native Debug/Release compilation; and the unsigned Version 1.0 / Build 29 iPhone archive. The earlier Intel simulator-install timeout is retained separately in the verification status.

`verification-status.json` records the exact source, automated results and remaining device checks.

1. Follow `Mac-upload-commands.txt`, confirm Version 1.0 / Build 29, then archive and upload with your Apple signing account.
2. Install Build 29 from TestFlight using the same BasketBoss review account and purchasing Apple Account.
3. Tap Restore Purchases once. Record its final message. If it fails, the displayed support code identifies the native error category without exposing account credentials or receipt data.
4. Complete the real-device Restore check before treating the purchase flow as signed off for App Review. The successful purchase and recipe-access evidence applies to Build 28; a Production billing test has not been performed.
5. Complete App Store Connect metadata, attach both subscriptions and select the final processed build before submitting for review. Enter the review password directly in App Store Connect.

## Included

- `Build-29-notes.md`: changes, test requirements and upload instructions.
- `Submission-steps-and-review-notes.md`: App Store Connect steps and reviewer notes.
- `App-Store-copy.txt`: suggested store copy.
- `Review-account-setup.txt`: review and Sandbox setup guidance, without credentials.
- `Live-Sandbox-observation.json`: user-confirmed Build 28 results and the unresolved Restore check.
- `verification-status.json`: exact candidate/release commits and automated checks.

Ten current iPad marketing images are available in the [screenshot download folder](https://github.com/jbatiste12-debug/BasketBoss/tree/build28-ipad-screenshots/app-store/ipad-build28). They are 2064 × 2752 opaque PNGs. Unzip the screenshot archive and upload the ten PNGs in numerical order under 13-inch iPad. The demonstrated feature layouts are unchanged by Build 29.

This workspace cannot sign, upload, install TestFlight on your phone or submit an App Review using your Apple account. No password is included in this handoff.
