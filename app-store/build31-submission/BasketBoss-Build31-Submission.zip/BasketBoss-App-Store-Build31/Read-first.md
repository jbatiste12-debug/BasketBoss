# BasketBoss 1.0 (31) — ready for signed TestFlight upload

Build 31 is merged and tagged at `appstore-build31-restore-flow`. The release commit is `b33d0aa42df21d60bbb93b4247d184298f53108c`; its complete source tree matches the verified candidate `946e80d83f74c71da57647508373a4cca3ca2413` exactly. [PR #87](https://github.com/jbatiste12-debug/BasketBoss/pull/87) records the change and validation.

The hosted full suite passed 2,789 checks with zero failures or skips and two existing TODOs. Native Debug/Release builds, Release test-fixture exclusion, hosted StoreKit restoration, Cook, both four-case keyboard runs, and the unsigned Build 31 iPhone archive passed. Details and provenance are in `verification-status.json` and the five native reports. Exact StoreKit executed totals were unavailable in the sanitized log; the passing hosted target and native smoke are recorded explicitly.

Build 31 reads verified current Apple entitlements before requesting forced history sync, then uses the server's ownership and current-status checks. Shopping and receipt reconciliation match actual food identity and exact quantities, preserve separate lots, and request review for unknown conversions. Read `Pantry-matching-checks.md` for examples.

## Upload from your Mac

1. Use `Mac-upload-commands.txt` to obtain the tagged source and run `npm ci` followed by `npm run ios:sync`. Alternatively, [download the tagged source ZIP](https://github.com/jbatiste12-debug/BasketBoss/archive/refs/tags/appstore-build31-restore-flow.zip) and run those commands from its extracted folder.
2. Open `ios/App/App.xcworkspace`. Confirm Version 1.0 / Build 31, bundle `uk.co.basketboss.app`, team `J25UTUATD2`. Choose Any iOS Device (arm64), then Product → Archive → Distribute App → App Store Connect → Upload.
3. Install Build 31 from TestFlight. Use the same BasketBoss and purchasing Apple Account, tap Restore Purchases once, and record the final message or support code. Existing Sandbox subscriptions follow Apple's accelerated renewal/expiry rules.
4. Check the shopping-to-At home flow on the device. Finish & update At home performs the stock transfer; ticking Bought records progress.
5. Complete App Store Connect metadata, attach both subscriptions, select the processed build and submit for review. Enter review credentials directly in App Store Connect.

Build 30 is the version last reported installed by the user. Build 31 signing/upload, real-device Restore and App Review submission remain pending. Automated local StoreKit verification does not establish Production billing success.

The ZIP contains upload guidance, matching rules and verification reports. The existing [ten iPad screenshots](https://github.com/jbatiste12-debug/BasketBoss/tree/build28-ipad-screenshots/app-store/ipad-build28) are available separately; review them against the selected submission build.
