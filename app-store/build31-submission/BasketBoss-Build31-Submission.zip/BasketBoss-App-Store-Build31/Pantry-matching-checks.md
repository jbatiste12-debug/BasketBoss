# Shopping, receipts and At home

The verified source candidate is `946e80d83f74c71da57647508373a4cca3ca2413` (Build 31, PR #87).

Match the physical food before adding quantities. Approved aliases can share stock; fresh tomatoes, tinned tomatoes and tomato purée cannot. Species, meaningful dietary variants and preparation states remain distinct. An unrecognized name becomes a separate item rather than a guessed match.

Exact measurement conversions are separate from food matching:

| Existing stock | Confirmed purchase | Result at Finish |
| --- | --- | --- |
| 0.5 kg pasta | 500 g pasta | 1 kg pasta |
| 1 litre milk | 500 ml milk | 1.5 litres milk |
| 2 tins with reviewed contents of 400 g each | 400 g of the same tinned food | 3 tins |
| 2 tins with unknown contents | 400 g | Keep the two tins and measured purchase separate; review contents |
| A food recorded in grams | The same food in ml without a reliable conversion | Keep separate and request review |
| Fresh tomatoes in grams | Tinned tomatoes in grams | Separate foods |

A receipt showing 2 × 300 g must not convert unknown tins using a default 400 g size. When a same-food conversion is unresolved, receipt stocking stops before a remote or local write and asks for saved pack contents to be confirmed in At home. Saving receipt prices only remains available. Once the contents are reviewed as 300 g, the receipt/Finish credit path nets 600 g once.

Older dated, reduced and frozen portions retain their quantities and labels. New purchases cannot inherit an older use-by date merely because the ingredient matches. Ambiguous reduced receipt annotations keep existing lots unchanged and show a review message after saving. Exact receipt totals can display in base measurement units.

Ticking Bought records shopping progress. **Finish & update At home** transfers the confirmed purchase quantities; a matching receipt uses the same purchase credit to avoid a second deposit. **Confirm cooked & update pantry** deducts the ingredients for the cooked servings using the existing completion ledger.

Validation includes 34 tests executing the actual Finish functions with the real food canonicalizer, cloud/local receipt reconciliation tests, and the complete 2,791-case local regression run: 2,788 passed, 0 failed, 1 native-only local skip, 2 existing TODOs. Hosted native and TestFlight device results are recorded separately in `verification-status.json`.
