# BasketBoss 1.0 (28) — App Store upload packet

Verified release tag: `appstore-build28-submission`

Release commit: `627b5d9cdaebe4fa4cbee0389e750b3376a839a9`

Use Build 28 for the App Store submission. Build 27 is already in TestFlight; a TestFlight upload does not submit an app for review.

## What is included

- `Mac-upload-commands.txt`: fetch the fixed release, sync iOS and open Xcode.
- `Submission-steps-and-review-notes.md`: build selection, subscriptions, metadata and suggested reviewer notes.
- `App-Store-copy.txt`: suggested description, subtitle, promotional text and keywords.
- `Review-account-setup.txt`: confirmed BasketBoss review login and Sandbox authorization.
- `verification-status.json`: exact source commits, checks, evidence links and unverified external steps.

## Changes

At home search and thumbnails now carry recognised foods into the editor. Tuna resolves to Tinned tuna with grams and the planned requirement. Custom foods and edited drafts remain supported; confirmation updates pantry and Shop without duplicate rows. The PWA food-entry fix is live.

The PWA keeps normal web Free/Premium plans and Paddle checkout, without Apple purchase, Restore Purchases or TestFlight activation controls. Existing Apple members can still see legitimate account status. iOS uses the real Apple monthly and annual purchase options. The shipping iOS membership screens no longer offer TestFlight beta activation; existing verified complimentary access remains valid.

## Verification

The hosted full suite passed 2,649 tests with no failures, no skips and two existing TODOs. Pantry browser checks passed all 28 cases at 375px and 320px in both ordinary-web and synthetic-iOS modes; before/served/after hashes match the released files. Actual StoreKitTest, Cook, native compilation and unsigned iPhone archive checks passed. A fresh standalone ARM keyboard run passed all four strict cases with zero failures/skips. The earlier Intel failure remains recorded separately; the final CI platform matches the proven Apple-silicon runner.

## Next steps in Apple

1. Follow the Mac commands, confirm Version 1.0 / Build 28 and archive/upload using your signing team.
2. After processing, select Build 28 on the App Store version 1.0 page, attach monthly and annual subscriptions, and complete the required app information.
3. Provide a dedicated confirmed BasketBoss app login in App Review Information and authorize that test account for Sandbox verification. Enter its password directly in App Store Connect.
4. Verify a real Apple Sandbox purchase and Restore Purchases against the live server. Local StoreKit products and simulated server replies do not prove this external path.
5. Add for Review, open the draft submission, then Submit for Review. Check that Apple shows Waiting for Review.

This workspace prepared and verified the source; it has not signed, uploaded or submitted Build 28 to Apple. App Store Connect metadata, review credentials and live Apple purchase/restore remain external checks.
