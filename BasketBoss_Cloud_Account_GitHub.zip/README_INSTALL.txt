BasketBoss iPhone PWA — GitHub Pages

Upload ALL of these to the same folder in your GitHub repository:
- index.html (replace the old one)
- manifest.webmanifest
- service-worker.js
- icons/icon-192.png
- icons/icon-512.png
- icons/apple-touch-icon.png

The file index_CODE.txt contains the complete index.html source as plain text.

On iPhone: open your GitHub Pages HTTPS website in Safari, tap Share,
choose Add to Home Screen, then Add. Launch from the new icon.

Notes:
- GitHub's repository code viewer does not install the app. Use the published GitHub Pages URL.
- First load requires internet; subsequent visits can open the cached app offline.
- Online recipe photos only work offline after they have been loaded at least once.
- Fridge AI scanning requires an online backend. Local photo upload does not recognize ingredients automatically.
- Saved plans are stored in this browser/device; this is not cloud sync.
- For an existing install, refresh online after deployment to receive updates.
