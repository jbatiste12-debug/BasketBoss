BASKETBOSS CLOUD ACCOUNT SETUP

This is email/password sign-in with Supabase, NOT Apple iCloud or Sign in with Apple.
It works on iPhone and desktop using the same BasketBoss account.

1. Create a free Supabase project at https://supabase.com
2. Open SQL Editor, paste supabase_setup.sql and run it.
3. Project Settings > API: copy Project URL and publishable (or legacy anon) key.
4. Edit cloud-config.js to insert these two values. NEVER paste a secret/service_role key.
5. In Supabase Authentication > URL Configuration set your Site URL to your
   published GitHub Pages URL. Configure email confirmation as desired.
6. Upload index.html, cloud-config.js, service-worker.js, manifest.webmanifest,
   and icons/ to your GitHub Pages repository.
7. Visit your published HTTPS site, open Account, create an account, and
   confirm email if required. Sign in on desktop and iPhone with same details.
8. On the device with your EXISTING meal plan choose 'Upload this device's plan'.
   On the second device choose 'Restore cloud plan' once.
9. Later edits auto-upload when signed in and online. To pick up edits made on
   another device, open Account and select 'Restore cloud plan'.

IMPORTANT LIMITATIONS:
- Account setup is NOT active until you configure Supabase.
- This is cloud sync, not iCloud / Apple ID sign-in.
- This version is last-write-wins; concurrent editing on two devices can overwrite
  changes. Use Restore before editing on another device.
- Offline edits save locally; auto-upload retries when internet reconnects if
  the app stays open. Relaunch and make another change if needed.
- Only app state is synced; recipe photos using external URLs are not uploaded.
- Cloud account passwords are handled by Supabase, not stored in the app's code.
- Existing local data is not erased by creating an account.
