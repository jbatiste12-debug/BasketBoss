-- Run once in Supabase SQL Editor.
create table if not exists public.basketboss_data (
 user_id uuid primary key references auth.users(id) on delete cascade,
 data jsonb not null,
 updated_at timestamptz not null default now()
);
alter table public.basketboss_data enable row level security;
revoke all on public.basketboss_data from anon;
grant select,insert,update,delete on public.basketboss_data to authenticated;
drop policy if exists "read own basket" on public.basketboss_data;
drop policy if exists "insert own basket" on public.basketboss_data;
drop policy if exists "update own basket" on public.basketboss_data;
drop policy if exists "delete own basket" on public.basketboss_data;
create policy "read own basket" on public.basketboss_data for select to authenticated using ((select auth.uid())=user_id);
create policy "insert own basket" on public.basketboss_data for insert to authenticated with check ((select auth.uid())=user_id);
create policy "update own basket" on public.basketboss_data for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy "delete own basket" on public.basketboss_data for delete to authenticated using ((select auth.uid())=user_id);
